"""
A Hangman game for:
Python Ready 1 - A Python Game Jam
Presented by CompSoc on 18/05/2017

Author: Amanda Deacon
Last modified: 16/May/2017
"""


class Game:
    """ Manage a single game of Hangman. """

    def __init__(self, word):
        self.word = word
        self.word_length = len(word)

        # This keeps track of the player's guesses so far.
        self.guesses = set()

        self.num_wrong_guesses = 0

        #  This is the gallows template string. As incorrect guesses are made,
        #  pieces of the hangman are "drawn" onto this template.
        #  Some formatting shenanigans have been used so that we could display
        #  this string over multiple lines within the code.

        self.gallows_template_string = ("   _____         \n"
                                        "   |   |         \n"
                                        "   |   {0}       \n"
                                        "   |  {2}{1}{3}  \n"
                                        "   |  {4} {5}    \n"
                                        "   |             \n"
                                        "__________       \n")

        #  This array contains the "pieces" of the hangman body. In order we
        #  have: head, chest, arm1, arm2, leg1, leg2.

        self.gallows_man = ['O', '|', '/', '\\', '/', '\\']

        self.num_allowed_incorrect_guesses = len(self.gallows_man) - 1

    def print_gallows(self):
        """ Print the hangman / gallows text art. The number of displayed 
         "body parts" is equal to the number of incorrect guesses so far. """

        body_parts = [self.gallows_man[i] if i < self.num_wrong_guesses
                      else " " for i in range(len(self.gallows_man))]
        print(self.gallows_template_string.format(*body_parts))

    def print_board(self):
        """ Print the word board. If a character has not yet been guessed, it 
         is represented as an underscore: ' _ ' . If a character has been 
         guessed, the character itself is displayed. """

        template = " {} "
        board = ""

        for char in self.word:
            if char in self.guesses:
                board += template.format(char)
            else:
                board += template.format("_")

        print("\n" + board + "\n")

    def get_valid_guess(self):
        """ Obtain and return a valid guess from the user. A guess is valid 
        if it is a single alphabetic character which has not previously been 
        guessed. Loop until a valid guess is obtained."""

        print("Guess a letter: ", end="")

        guess = input().strip().lower()
        valid_guess = False

        ###############################
        # UNCOMMENT THESE LINES BELOW #
        ###############################
        #
        # while not valid_guess:
        #     if guess in self.guesses:
        #         print("That letter has already been guessed. Try again: ", end="")
        #     elif not guess.isalpha():
        #         print("The guess must be an alphabet character. Try again: ", end="")
        #     elif len(guess) > 1:
        #         print("The guess must be a single character. Try again: ", end="")
        #     else:
        #         valid_guess = True
        #
        #     if not valid_guess:
        #         guess = input().strip().lower()
        #
        ###############################
        # UNCOMMENT THESE LINES ABOVE #
        ###############################

        return guess

    def play_turn(self):
        """ Obtain and record a valid player character guess. Print a success 
        message if the character occurs in the hidden word. Otherwise print a 
         failure message. """

        guess = self.get_valid_guess()
        self.guesses.add(guess)

        if guess in self.word:
            print("Yes, '{}' is in the word!\n".format(guess))
        else:
            print("Nope, '{}' is not in the word.\n".format(guess))
            self.num_wrong_guesses += 1

    def is_game_won(self):
        """ Return True if the user has guessed every letter in the hidden 
        word. Return False otherwise. """

        ####################################
        # Temporary code to start off.     #
        # Remove this when you have        #
        # completed the function yourself. #
        ####################################
        return False

        #############################
        # YOUR CODE GOES BELOW HERE #
        #############################
        #
        # ...

    def is_game_lost(self):
        """ Return True if the number of incorrect guesses is greater than 
        the number of allowed incorrect guesses. """

        ####################################
        # Temporary code to start off.     #
        # Remove this when you have        #
        # completed the function yourself. #
        ####################################
        return False

        #############################
        # YOUR CODE GOES BELOW HERE #
        #############################
        #
        # ...

    def print_win_message(self):
        print("You win! The word was '{}'.".format(self.word))

    def print_loss_message(self):
        print("Aw, game over! The word was '{}'".format(self.word))

    def play(self):
        """ Play a single game of Hangman. Return 1 if the game is won by
         the user, or return 0 if the game is lost by the user. """

        print("New game! The word is {} letters long.".format(self.word_length))
        score = 0
        is_game_over = False

        #############################
        # YOUR CODE GOES BELOW HERE #
        #############################
        #
        # while not is_game_over:
        #     ...
        #
        #############################
        # YOUR CODE GOES ABOVE HERE #
        #############################

        return score


class Session:
    """ Manage a series of Hangman games. """

    def __init__(self, word_list):
        self.word_list = word_list
        self.game_count = 0
        self.win_count = 0

    @staticmethod
    def user_yes_response():
        """ Return True if user responds 'y' for yes. Return False if user
         responds 'n' for no. Check repeatedly until a valid user response
          is given. """

        answer = input().strip()

        while answer.lower() not in ["y", "n"]:
            print("Oops! I didn't understand that. Please respond y or n:",
                  end="")
            answer = input().strip()
        return answer == "y"

    def pick_random_word(self):
        """ Select and return a random word from self.word_list """

        ####################################
        # Temporary code to start off.     #
        # Remove this when you have        #
        # completed the function yourself. #
        ####################################
        return 'banana'

        #############################
        # YOUR CODE GOES BELOW HERE #
        #############################
        #
        # ...

    def display_summary(self):
        """ Print a summary of the win / loss statistics for this session. """

        print("\nWins: {}. Losses: {}.\n".format(
            self.win_count, self.game_count - self.win_count))

    def run(self):
        """ Repeatedly initiate games of Hangman while the user responds
         yes. Track win / loss statistics and display a summary after each 
         game. """

        print("\nWelcome to Super Hangman 3000!!!")
        print("Would you like to start a game? (y/n): ", end="")

        yes_response = self.user_yes_response()

        while yes_response:
            print("Starting a new game...\n")

            ####################################
            # Temporary code to start off.     #
            # Remove this when you have        #
            # completed the function yourself. #
            ####################################
            print("A game gets played here!")

            #############################
            # YOUR CODE GOES BELOW HERE #
            #############################
            #
            # ...
            #
            #############################
            # YOUR CODE GOES ABOVE HERE #
            #############################

            print("Play again? (y/n): ", end="")
            yes_response = self.user_yes_response()

        print("\nOk, goodbye!")


def read_word_list(filename):
    """ Return a list of words read from the given filename. Ignore any 
    words which are fewer than 3 characters long. """

    infile = open(filename)
    word_list = []

    for line in infile.readlines():
        word = line.strip()
        if len(word) > 2:
            word_list.append(word)

    infile.close()
    return word_list


def main():
    """ The main function: initiate a session of games. """

    print("Creating the word list ...")
    word_list = read_word_list("english_words.txt")
    session = Session(word_list)

    print("Starting a session ...")
    session.run()


if __name__ == "__main__":
    main()
