"""Handles input events"""
def key_pressed(event):
	print(event.keysym)
	if event.keysym == "Up":
		piece.drop()
		piece.__init__()
	else:
		dx = dy = rot = 0
		if event.keysym == "Left": 
			dx = -1
		elif event.keysym == "Right":
			dx = 1
		elif event.keysym == "Down":
			dy = 1
		elif event.keysym == "space":
			rot = 1
		piece.move(dx, dy, rot)
		




def main():
	
	prev_drop_time = time.time()
	
	
	while True:
		
		t = time.time()
		if t >= prev_drop_time + fall_delay:
			if piece.is_landed(): 
				piece.land()
			else:
				piece.move(0, 1, 0)
			prev_drop_time = t
		
		canvas.delete("all")
		draw_well()
		piece.draw()
		
		canvas.update()
		

"""Takes a single world x and y, converts them into screen x and y, and draws a block a specified colour there"""
def draw_block(wellx, welly, colour):
	x, y = wellx*block_size, welly*block_size
	canvas.create_rectangle(x, y, x+block_size, y+block_size, fill=colour)


"""Draws all blocks in the well"""
def draw_well():
	for x in range(well_width):
		for y in range(well_height):
			draw_block(x, y, well[x][y])
	


"""Clears all full rows and drops blocks down appropriately"""
def clear_rows():
	#### Write your code here. Modify the global well appropriately. Remove pass when you're done ####
	pass
			




class Tetronimo:
	colour = "black" #The colour of the tetromino. 
	coords = [[0, 0], [0, 0], [0, 0], [0, 0]] #The [x, y] world coordinates of the four blocks that make up the tetronimo. 
	
	
	"""Initializes the piece to a random tetromino"""
	def __init__(self):
		shape = randint(0, 6)
		
		if shape == 0: #I
			self.colour = "cyan"
			self.coords = [[well_width/2-1, 0], [well_width/2, 0], [well_width/2+1, 0], [well_width/2+2, 0]]
		elif shape == 1: #J
			self.colour = "red"
			self.coords = [[well_width/2-1, 0], [well_width/2, 0], [well_width/2+1, 0], [well_width/2+1, 1]]
		elif shape == 2: #L
			self.colour = "green"
			self.coords = [[well_width/2-1, 0], [well_width/2, 0], [well_width/2+1, 0], [well_width/2-1, 1]]
		elif shape == 3: #S
			self.colour = "blue"
			self.coords = [[well_width/2, 0], [well_width/2+1, 0], [well_width/2, 1], [well_width/2-1, 1]]
		elif shape == 4: #Z
			self.colour = "yellow"
			self.coords = [[well_width/2-1, 0], [well_width/2, 0], [well_width/2, 1], [well_width/2+1, 1]]
		elif shape == 5: #T
			self.colour = "magenta"
			self.coords = [[well_width/2-1, 0], [well_width/2, 0], [well_width/2+1, 0], [well_width/2, 1]]
		elif shape == 6: #O
			self.colour = "white"
			self.coords = [[well_width/2, 0], [well_width/2, 1], [well_width/2+1, 0], [well_width/2+1, 1]]
			
			
		if self.is_colliding(): exit()
		
		return None
	
	
	
	"""Returns a transformed copy of the tetromino: translated by dx and dy, and rotated by 90 degrees if rot == 1"""
	def transformed(self, dx, dy, rot):
		new = copy.deepcopy(self)
		
		for i in range(4): #Translate
			new.coords[i][0] += dx
			new.coords[i][1] += dy

		#### Write your code here. Rotate the Tetronimo new ####
		
		return new
		
		
	
	"""Draws the tetromino at the correct location on the board"""
	def draw(self):
		#### Write your code here. Draw the Tetronimo self. Remove pass when you're done ####
		pass
	
	
	
	
	
	
	#Class aux functions
	
	
	
	"""Returns if the tetromino is intersecting any walls or blocks in the well"""
	def is_colliding(self): 
		for block in self.coords:
			if not(int(block[0]) in range(0, well_width) and int(block[1]) in range(0, well_height) and square_free(int(block[0]), int(block[1]))): return True
		return False
	
	
	"""Returns if the piece is directly over a block or the bottom of the well"""
	def is_landed(self):
		return self.transformed(0, 1, 0).is_colliding()
	
		
		
	"""Transfers the piece data from the tetromino object to the well and reinitializes the tetromino"""
	def land(self):
		for block in self.coords:
			well[int(block[0])][int(block[1])] = self.colour
		clear_rows()
		self.__init__()
	
	
	"""Transforms/moves the piece, if allowed"""
	def move(self, dx, dy, rot): #Increments of 1 block
		new = self.transformed(dx, dy, rot)
		
		if not new.is_colliding():
			self.coords = copy.deepcopy(new.coords)
			
	
	"""Drops the piece all the way to the bottom of the well, as a tool to speed up gameplay"""
	def drop(self): #Hard drop to the bottom of the well. 
	
		while not self.is_landed():
			self = self.transformed(0, 1, 0)
		
		self.land()
	
	

	"""Return if a cell in the well is free"""
def square_free(x, y):
		return well[x][y] == "black" 


	
	
	
			
import time, sys, copy
from math import floor
from random import randint
from tkinter import *


block_size = 30 #In pixels
well_width = 10 #In blocks, not pixels. 
well_height = 20 #In blocks. 

window_width = block_size*well_width
window_height = block_size*well_height

fall_delay = 1 #secs

well = [["black" for i in range(well_height)] for j in range(well_width)] # a well_width by well_height array of black colour tuples
	
	
window = Tk()
canvas = Canvas(window, width=window_width, height=window_height, bg='black')

window.bind("<Key>", key_pressed)

canvas.pack()	


piece = Tetronimo() #There is only ever one active at a time - this one. 




main()
